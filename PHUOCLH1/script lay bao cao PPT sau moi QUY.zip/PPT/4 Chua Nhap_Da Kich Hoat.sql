select CIF, 
    LOC,
    HOTEN,
    SDT,
    (select px_irpanmap_panmask from ir_pan_map where px_irpanmap_pan = SO_THE AND ROWNUM <= 1) as so_the_che,
    LOAI_THE,
    NGAY_PHAT_HANH,
    DON_VI,
    TEN_DON_VI,
    TINH_TRANG_NHAP,
    NGAY_DV_NHANTHE_TU_MKS
from
(select
    PX_IR025_PAN as so_the,
    F9_IR025_LOC_ACCT as loc,
    (select trim(FX_IR056_CIF_NO) from ir056 where F9_IR025_CRN = P9_IR056_CRN and rownum <= 1) CIF,
    (select trim(FX_IR056_NAME) from ir056 where F9_IR025_CRN = P9_IR056_CRN and rownum <= 1) HOTEN,
    (select trim(FX_IR056_HP) from ir056 where F9_IR025_CRN = P9_IR056_CRN and rownum <= 1) SDT,        
    trim(fx_ir025_crd_pgm) as loai_the,
    f9_ir025_issue_dt as ngay_phat_hanh,
    trim(fx_ir025_brch_cde) as don_vi,    
    (SELECT trim(BRANCH_NAME) from full_branch where trim(BRANCH_CODE) = trim(fx_ir025_brch_cde)) TEN_DON_VI,
    
    nvl((select 'CHUA NHAP' from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') or ISSUE_TYPE = 'REPLACEMENT') 
    and TRANS_CUST_DATE is null
    and trans_cust_lock = 0 
    AND TRANS_CUST_ISCHECK = 0 
    AND ROWNUM <= 1),'DA NHAP') as TINH_TRANG_NHAP,       
    
    (select TRANS_CUST_STATUS from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT') and TRANS_CUST_DATE is not null AND TRANS_CUST_ISCHECK = 0 AND ROWNUM <= 1) as TINH_TRANG_TREN_PPT , 
    
    nvl((select max(f9_il006_crd_atv_dt) from il006 where fx_il006_pan = PX_IR025_PAN),f9_ir025_crd_atv_dt) as NGAY_KICH_HOAT_DAU_TIEN,
    
    (select TRANS_BRANCH_REC_DATE from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT') AND ROWNUM <= 1) as NGAY_DV_NHANTHE_TU_MKS    
from ir025
where
    FX_IR025_CLS = ' '
    and F9_IR025_CNCL_DT = 0
    and F9_IR025_REN_DT = 0
    --and fx_ir025_crd_brn <> 'LC'
    and (select trim(FX_IW104_CRD_CAT) from iw104 where FX_IW104_PAN = PX_IR025_PAN and rownum <= 1) not in ('RENEWAL', 'UP/DOWNGRDE', 'REPLACEMENT')
    and f9_ir025_issue_dt >= 20190101 and f9_ir025_issue_dt <= 20200225
    and F9_IR025_CRD_ATV_DT != 0--DA KICH HOAT
)
where TINH_TRANG_NHAP = 'CHUA NHAP'
and SO_THE not in (select PAN 
                    from fpt.ppt_crd_detail@dw 
                    where CRD_PRIN_SUPP = 'P' 
                    and trim(CRD_TYPE) in  (select trim(PX_IR121_CRD_PGM) 
                                        from ir121 
                                        where F9_IR121_PRFX in ('5471390', '5471391', '512454')
                                        and ISSUE_DATE >= 20190101 and ISSUE_DATE <= 20200225))
and SO_THE not in(select PAN from fpt.ppt_crd_detail@dw where ISSUE_DATE >= 20190101 and ISSUE_DATE <= 20200225 and FW_BRN_CDE is not null)                                                                                

