--select * from ppt_crd_detail where ISSUE_DATE = 20200211
select CIF_NO,
    CUST_NAME HOTEN,
    (select px_irpanmap_panmask from ir_pan_map@im where px_irpanmap_pan = PAN AND ROWNUM <= 1) as so_the_che,
    CRD_TYPE LOAI_THE,
    ISSUE_TYPE NGAY_PHAT_HANH,
    BRCH_CDE,
    TRANS_BRANCH_REC_DATE NGAY_DV_NHANTHE_TU_MKS,
    TRANS_CUST_DATE NGAYNHAP_GIAOTHE_KH,
    (case when TRANS_CUST_STATUS = '01' then 'GIAO THE THANH CONG'
               when TRANS_CUST_STATUS = '02' then 'KH TU CHOI NHAN THE'
               when TRANS_CUST_STATUS = '03' then 'KH HEN DEN NHAN'
               when TRANS_CUST_STATUS = '04' then 'KHONG LIEN LAC DUOC KH'
               when TRANS_CUST_STATUS = '05' then 'DA CHUYEN DOI TAC PHT'
               when TRANS_CUST_STATUS = '06' then 'LY DO KHAC'
               when TRANS_CUST_STATUS = '07' then 'THE CHON SAI THONG SO'
               else '' end) as TRANS_CUST_STATUS
from ppt_crd_detail where ISSUE_DATE >= 20190101 and ISSUE_DATE <= 20191231 and TRANS_CUST_STATUS = '02' and TRANS_CUST_ISCHECK = 1
