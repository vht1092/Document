select CIF, loai_the, HOTEN, so_the, ngay_phat_hanh, don_vi, CHUYEN_DON_VI_GIAO_THE,
 TEN_DON_VI, NGAY_CHUYEN_FILE_MKS, NGAY_DON_VI_NHAN_THE_MKS,
       NGAY_NHAP_BUOC_GIAO_THE_KH, 
       (case when TINH_TRANG_TREN_PPT = '01' then 'GIAO THE THANH CONG'
               when TINH_TRANG_TREN_PPT = '02' then 'KH TU CHOI NHAN THE'
               when TINH_TRANG_TREN_PPT = '03' then 'KH HEN DEN NHAN'
               when TINH_TRANG_TREN_PPT = '04' then 'KHONG LIEN LAC DUOC KH'
               when TINH_TRANG_TREN_PPT = '05' then 'DA CHUYEN DOI TAC PHT'
               when TINH_TRANG_TREN_PPT = '06' then 'LY DO KHAC'
               else '' end) as TINH_TRANG_TREN_PPT,
        TINH_TRANG_DUYET_GIAO_THE_KH,
        SALEOFFICER_CODE
from
(select
    (select px_irpanmap_panmask from ir_pan_map where px_irpanmap_pan = PX_IR025_PAN AND ROWNUM <= 1) as so_the,
    
    F9_IR025_LOC_ACCT as loc,
    (select trim(FX_IR056_CIF_NO) from ir056 where F9_IR025_CRN = P9_IR056_CRN and rownum <= 1) CIF,
    
    (select trim(FX_IR056_NAME) from ir056 where F9_IR025_CRN = P9_IR056_CRN and rownum <= 1) HOTEN,
    
    trim(fx_ir025_crd_pgm) as loai_the,
    
    f9_ir025_issue_dt as ngay_phat_hanh,
    
    trim(fx_ir025_brch_cde) as don_vi,
    
    (select FX_IR025_SLS_OFC_CDE from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT')) as SALEOFFICER_CODE,
    
    (SELECT trim(BRANCH_NAME) from full_branch where trim(BRANCH_CODE) = trim(fx_ir025_brch_cde)) TEN_DON_VI,
    
    (select FW_BRN_CDE from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT')) as CHUYEN_DON_VI_GIAO_THE,
    
    (select TRANS_MK_DATE from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT')) as NGAY_CHUYEN_FILE_MKS,
    
    (select TRANS_BRANCH_REC_DATE from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT')) as NGAY_DON_VI_NHAN_THE_MKS,
    
    (select TRANS_CUST_DATE from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT')) as NGAY_NHAP_BUOC_GIAO_THE_KH,
          
    (select TRANS_CUST_STATUS from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') 
    or ISSUE_TYPE = 'REPLACEMENT') AND ROWNUM <= 1) as TINH_TRANG_TREN_PPT,
    
    nvl((select 'CHUA DUYET' from fpt.ppt_crd_detail@dw 
    where pan = PX_IR025_PAN 
    and ((to_number(issue_date) = f9_ir025_issue_dt and ISSUE_TYPE <> 'REPLACEMENT') or ISSUE_TYPE = 'REPLACEMENT') 
    AND TRANS_CUST_ISCHECK = 0  
    AND ROWNUM <= 1),'DA DUYET') as TINH_TRANG_DUYET_GIAO_THE_KH
from ir025@im
where
    f9_ir025_issue_dt >= 20200101 and f9_ir025_issue_dt <= 20200403)
    FX_IR025_CLS = ' '
    and F9_IR025_CNCL_DT = 0
    and F9_IR025_REN_DT = 0
    --and fx_ir025_crd_brn <> 'LC'    
    
    and PX_IR025_PAN not in (SELECT   PAN
                          FROM   fpt.ppt_crd_detail@dw
                         WHERE   TRIM (crd_type) IN
                                         (SELECT   TRIM (px_ir121_crd_pgm)
                                            FROM   ir121
                                           WHERE   f9_ir121_prfx IN ('5471390', '5471391', '512454'))
                                           and CRD_PRIN_SUPP = 'P')
    --and F9_IR025_CRD_ATV_DT != 0--DA KICH HOAT
)
